
import stockQuote


x = stockQuote.myQuote("SPX", "1min", 3)
x.getQuote()
