#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
__init__.py
(c) Will Roberts  18 February, 2015

pytimeparse.tests module
'''
